# Toolbar []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/toolbar.md)

---

## Basic Toolbar

Use las opciones `search`, `showColumns`, `showRefresh`, `showToggle` para mostrar una barra de herramientas básica. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/33/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## Custom Toolbar

Use la opción `toolbar` para definir una barra de herramientas customizada. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/34/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>